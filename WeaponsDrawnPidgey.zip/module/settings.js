
export const registerSettings = function () {
};
